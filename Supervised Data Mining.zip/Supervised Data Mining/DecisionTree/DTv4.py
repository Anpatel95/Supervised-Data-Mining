import pandas as pd
from sklearn.model_selection import KFold 
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

'''   #  Attribute                     Domain
   -- -----------------------------------------
   1. Sample code number            id number
   2. Clump Thickness               1 - 10
   3. Uniformity of Cell Size       1 - 10
   4. Uniformity of Cell Shape      1 - 10
   5. Marginal Adhesion             1 - 10
   6. Single Epithelial Cell Size   1 - 10
   7. Bare Nuclei                   1 - 10
   8. Bland Chromatin               1 - 10
   9. Normal Nucleoli               1 - 10
  10. Mitoses                       1 - 10
  11. Class:                        (2 for benign, 4 for malignant) 
  
  Attribute 2 - 10 will be divided into two groups 1-5 and 6-10
  '''

if __name__ == "__main__":
    col_header = ['ID', 'Clump-Thickness', 'Uniformity-Size', 'Uniformity-Shape', 'Maginal-Adhesion',
              'Single-Epithelial', 'Bare-Nuclei', 'Bland-Chromatin', 'Normal-Nucleoli', 'Mitoses', 'class-type']
    data = pd.read_csv(
        '/Users/An Patel/Documents/Final Project-Data Mining/breast-cancer-wisconsin.data', sep=',', names=col_header)

    #performing data clean up
    rowDel = []
    nr = 0
    for index, row in data.iterrows():
        if row[6] == '?':
            rowDel.append(index)

    #clean data
    data = data.drop(labels=rowDel, axis=0)
    data = data.reset_index()

    #parse data into raw data and class type
    only_data = data.iloc[:, 1:-1]
    class_type = data.iloc[:, -1]

    #compute k-fold
    total_k = 10
    k_fold = KFold(n_splits=total_k, random_state=None)

    #lists to store Accuracy Rate and Error Rate 
    accuracyLst = []
    errorLst = []

    #perform 10 k-fold and splites the dataset into training and testing
    for train_index , test_index in k_fold.split(only_data):

        X_train , X_test = only_data.iloc[train_index,:], only_data.iloc[test_index,:]
        y_train , y_test = class_type[train_index] , class_type[test_index]

        #training the Decision Tree Classifier
        train_DTclassifer = DecisionTreeClassifier()
        train_DTclassifer.fit(X_train, y_train)

        #testing the classifier
        pred_class = train_DTclassifer.predict(X_test)

        #calcualte Accuracy and Error Rate
        accuracy_rate = accuracy_score(pred_class, y_test)
        error_rate = 1 - accuracy_rate

        #store Accuracy and Error Rate into List
        accuracyLst.append(round(accuracy_rate * 100, 2))
        errorLst.append(round(error_rate * 100, 2))

    #Average Accuracy Rate
    avgAccuracy = round(sum(accuracyLst) / len(accuracyLst), 2)

    #print output
    print("Decision Tree".rjust(35, " "))
    print("{:<50} {:<10}".format("Accuracy Rate", "Error Rate"))
    for ind in range(len(accuracyLst)):
        print("{:<50} {:<10}".format(str(accuracyLst[ind])+" %", str(errorLst[ind])+" %"))

    print("Averate Accuracy = ", str(avgAccuracy) , "%")