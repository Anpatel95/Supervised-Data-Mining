import pandas as pd
from sklearn.model_selection import KFold

'''   #  Attribute                     Domain
   -- -----------------------------------------
   1. Sample code number            id number
   2. Clump Thickness               1 - 10
   3. Uniformity of Cell Size       1 - 10
   4. Uniformity of Cell Shape      1 - 10
   5. Marginal Adhesion             1 - 10
   6. Single Epithelial Cell Size   1 - 10
   7. Bare Nuclei                   1 - 10
   8. Bland Chromatin               1 - 10
   9. Normal Nucleoli               1 - 10
  10. Mitoses                       1 - 10
  11. Class:                        (2 for benign, 4 for malignant) 
  
  Attribute 2 - 10 will be divided into two groups 1-5 and 6-10
  '''


def main(trainDataset, testDataset):

    #calculate total positive and negative in dataset
    def calcPosNeg(lstClass):
        pos = lstClass.count(2)
        neg = lstClass.count(4)
        return pos, neg

    #division funtion for probability
    def calcProbab(numer,denom):
        return round(numer/denom, 3)

     # dataset with ID, single Attr, classes
    def find_singleAttrProb(dataset):

        #get total Positive and Negative for probability calculation
        totalpos, totalneg = calcPosNeg(dataset[10].tolist())

        #getting attribute name
        attrName = dataset.columns[1]

        leftdataset = pd.DataFrame(columns=list(dataset.columns))
        rightdataset = pd.DataFrame(columns=list(dataset.columns))
 
        for index, row in dataset.iterrows(): 

            tempLst = [list(row)]
            tempdf = pd.DataFrame(tempLst,columns=list(dataset.columns))

            #check and seperate data 
            if int(row[attrName]) <= 1:
                leftdataset = leftdataset.append(tempdf, ignore_index = True)

            elif int(row[attrName]) >= 2:
                rightdataset = rightdataset.append(tempdf, ignore_index = True)

        #get positive and negative from left and right dataset for n<=1 and n>=2
        totalleftPos, totalleftNeg = calcPosNeg(leftdataset[10].tolist())
        totalrightPos, totalrightNeg = calcPosNeg(rightdataset[10].tolist())

        #Compute Probability of Positive Negative for n<=1 and n>=2
        probPosleft = calcProbab(totalleftPos,totalpos)
        probPosright = calcProbab(totalrightPos,totalneg)

        probNegleft = calcProbab(totalleftNeg, totalneg)
        probNegright = calcProbab(totalrightNeg, totalneg)

        #store values into the probability Dics
        key = getKey(attrName)

        probPosLeftAttr[key] = probPosleft
        probPosRightAttr[key] = probPosright

        probNegLeftAttr[key] = probNegleft
        probNegRightAttr[key] = probNegright
        #single Attribute probability function ends

    #computes probability of each attribute one by one
    def computeAllAttrProb(lst_attr, dataset):
        print()
        for x in range(len(lst_attr)):
            attrIndx = list(header_Indx).index(lst_attr[x])
            attrsubInfo = dataset[[0, attrIndx, 10]].copy()
            find_singleAttrProb(attrsubInfo)

    #Used for getting the attribute Name from Static Dics
    def getKey(val):
        for key, value in header_Indx.items():
            if val == value:
                return key
    
    #for test dataset to make the prediction
    def testPhase(dataset):
        #compute positive probability of test
        def compPositive(probLst):
            tempcompLst =[]

            for x in range(len(probLst)):
                if probLst[x] == "left":
                    tempcompLst.append(probPosLeftAttr[getKey(x)])
                elif probLst[x] == "right":
                    tempcompLst.append(probPosRightAttr[getKey(x)])

            postValue = totalProbPos
            for x in tempcompLst:
                postValue *= x
            return postValue

        #compute Negative probability of test
        def compNegative(negLst):
            tempcompLst =[]

            for x in range(len(negLst)):
                if negLst[x] == "left":
                    tempcompLst.append(probNegLeftAttr[getKey(x)])
                elif negLst[x] == "right":
                    tempcompLst.append(probNegRightAttr[getKey(x)])

            negValue = totalProbNeg
            for x in tempcompLst:
                negValue *= x
            return negValue

        output = []

        def getProb():
            #loop through each row of the test dataset
            for index, row in dataset.iterrows():
                singleRow = list(row)
                tempProbRow = ["temp"]

                #loop to look the unlabel data and skip actual class and Id
                for x in range(1, len(singleRow)-1):
                    #To find right or left side probability
                    if int(singleRow[x]) <=1:
                        tempProbRow.append("left")

                    elif int(singleRow[x]) >= 2:
                        tempProbRow.append("right")

                #compute Positive and Negative Probability of unlabel data
                compP = compPositive(tempProbRow)
                compN = compNegative(tempProbRow)

                if compP >= compN:
                    output.append([singleRow[10], 2])
                else:
                    output.append([singleRow[10], 4])     
        getProb()
        #reture predection and actutal class outcome
        return output
        #test function ends

    #calc true and false predections
    def calcPrediction(output):
        tp = output.count([2, 2])
        fp = output.count([2, 4])

        tn = output.count([4, 4])
        fn = output.count([4, 2])
        return tp, fp, tn, fn

    #calc Accuracy Rate
    def accuracy(tp, fp, tn, fn):
        return round(((tp+tn)/(tp+fp+fn+tn)) * 100, 2)

    #calc Error Rate
    def errorRate(tp, fp, tn, fn):
        return round(((fp+fn)/(tp+fp+fn+tn)) * 100, 2)

    #datastructure to store the computed values
    probPosLeftAttr = {'Clump-Thickness': 0, 'Uniformity-Size': 0, 'Uniformity-Shape': 0, 'Maginal-Adhesion': 0,
                'Single-Epithelial': 0, 'Bare-Nuclei': 0, 'Bland-Chromatin': 0, 'Normal-Nucleoli': 0, 'Mitoses': 0}
    
    probPosRightAttr = {'Clump-Thickness': 0, 'Uniformity-Size': 0, 'Uniformity-Shape': 0, 'Maginal-Adhesion': 0,
                'Single-Epithelial': 0, 'Bare-Nuclei': 0, 'Bland-Chromatin': 0, 'Normal-Nucleoli': 0, 'Mitoses': 0}

    probNegLeftAttr = {'Clump-Thickness': 0, 'Uniformity-Size': 0, 'Uniformity-Shape': 0, 'Maginal-Adhesion': 0,
                'Single-Epithelial': 0, 'Bare-Nuclei': 0, 'Bland-Chromatin': 0, 'Normal-Nucleoli': 0, 'Mitoses': 0}

    probNegRightAttr = {'Clump-Thickness': 0, 'Uniformity-Size': 0, 'Uniformity-Shape': 0, 'Maginal-Adhesion': 0,
                'Single-Epithelial': 0, 'Bare-Nuclei': 0, 'Bland-Chromatin': 0, 'Normal-Nucleoli': 0, 'Mitoses': 0}

    header_Indx = {'ID': 0, 'Clump-Thickness': 1, 'Uniformity-Size': 2, 'Uniformity-Shape': 3, 'Maginal-Adhesion': 4,
                   'Single-Epithelial': 5, 'Bare-Nuclei': 6, 'Bland-Chromatin': 7, 'Normal-Nucleoli': 8, 'Mitoses': 9}

    header = ['Clump-Thickness', 'Uniformity-Size', 'Uniformity-Shape', 'Maginal-Adhesion',
              'Single-Epithelial', 'Bare-Nuclei', 'Bland-Chromatin', 'Normal-Nucleoli', 'Mitoses']

    #calc total positive probability and total negative probability
    totalpositive, totalnegative = calcPosNeg(trainDataset[10].tolist())

    totalProbPos = calcProbab(totalpositive,trainDataset.shape[0])
    totalProbNeg = calcProbab(totalnegative,trainDataset.shape[0])

    #train the classifier
    computeAllAttrProb(header, trainDataset)

    #test the classifier
    output = testPhase(testDataset)

    #count prediction and actutal class
    tp, fp, tn, fn = calcPrediction(output)

    #compute accuracy and error rate
    accuracyPer = accuracy(tp, fp, tn, fn )
    errorRatePer = errorRate(tp, fp, tn, fn)

    return accuracyPer, errorRatePer


if __name__ == "__main__":
    data = pd.read_csv(
        '/Users/An Patel/Documents/Final Project/breast-cancer-wisconsin.data', sep=',', header=None)

    #performing data clean up
    rowDel = []
    for index, row in data.iterrows():
        if row[6] == '?':
            rowDel.append(index)

    #clean data
    data = data.drop(labels=rowDel, axis=0)

    #compute k-fold
    total_k = 10
    k_fold = KFold(n_splits=total_k, random_state=None)

    #lists to store Accuracy Rate and Error Rate 
    accuracyLst = []
    errorLst = []

    #perform 10 k-fold and splites the dataset into training and testing
    for train_index , test_index in k_fold.split(data):

        train_dataset = data.iloc[train_index,:]
        test_dataset = data.iloc[test_index,:]

        #Classifier
        accry, error = main(train_dataset, test_dataset)

        accuracyLst.append(accry)
        errorLst.append(error)

    #Average Accuracy Rate
    avgAccuracy = round(sum(accuracyLst) / len(accuracyLst), 2)

    #print Accuracy Rate and Error Rate
    print("Navie Bayes".rjust(35, " "))
    print("{:<50} {:<10}".format("Accuracy Rate", "Error Rate"))
    for ind in range(len(accuracyLst)):
        print("{:<50} {:<10}".format(str(accuracyLst[ind])+" %", str(errorLst[ind])+" %"))

    print("Averate Accuracy = ", str(avgAccuracy) , "%")




